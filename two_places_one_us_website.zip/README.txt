TWO PLACES, ONE US — birthday website

FILES
- index.html: the complete website. It works as a single file and needs no images, accounts, or paid services.

QUICK PREVIEW ON IPHONE
1. Save index.html to the Files app.
2. Tap it to preview. If it opens as text, use a free HTML preview app or publish it using the steps below.

FREE PUBLISHING OPTION: GITHUB PAGES (no payment required)
This setup is easiest with a GitHub account. You can do it from Safari on your iPhone.
1. Open https://github.com and sign in or create a free account.
2. Create a new public repository named `two-places-one-us`.
3. Choose “Add file” → “Upload files”, then upload `index.html`.
4. Commit the file to the `main` branch.
5. Open the repository's Settings → Pages.
6. Under “Build and deployment”, choose “Deploy from a branch”; choose branch `main` and folder `/(root)`, then Save.
7. Wait a few minutes. Your site address will look like:
   https://YOUR-USERNAME.github.io/two-places-one-us/
   Replace YOUR-USERNAME with your GitHub username. GitHub will show the published address in Pages settings.
8. Open the address on your phone to test it, then send the link to Baby.

PRIVACY
A public GitHub Pages site can be opened by anyone who has the link, and the repository itself is public. Don't include private information you wouldn't want shared. You can delete the repository after his birthday if you prefer.

PERSONAL TOUCH
You can edit the wording in index.html before uploading. Search for “Happy birthday, Baby” or the memory text and change anything that doesn't sound exactly like you.
